<i style="color:blue;font-size:30px;font-family:calibri ;">
      FATIH KUCUKGOKMEN </i> <i style="color:green;font-size:30px;font-family:calibri ;">
      FATIH KUCUKGOKMEN </i> <i style="color:red;font-size:30px;font-family:calibri ;">
      FATIH KUCUKGOKMEN </i> 
